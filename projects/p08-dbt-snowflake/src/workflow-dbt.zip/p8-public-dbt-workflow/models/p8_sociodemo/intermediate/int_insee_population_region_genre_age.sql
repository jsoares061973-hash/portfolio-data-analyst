-- Agrégation INSEE par région, genre et tranche d'âge harmonisée

select
    region,
    genre,
    tranche_age,
    sum(population) as population_insee_2025
from (
    select
        case
            when r.libelle in (
                'Guadeloupe',
                'Guyane',
                'La Réunion',
                'Martinique',
                'Mayotte'
            )
                then 'DROM'
            else r.libelle
        end as region,
        i.genre,
        case
            when i.tranche_age in ('60-74', '75+')
                then '60+'
            else i.tranche_age
        end as tranche_age,
        i.population
    from {{ ref('stg_insee_population_departement_genre_age') }} i
    left join {{ source('openclassrooms', 'cog_departements') }} d
        on i.dep = d.dep
    left join {{ source('openclassrooms', 'cog_regions') }} r
        on d.reg = r.reg
) as insee_region
group by
    region,
    genre,
    tranche_age