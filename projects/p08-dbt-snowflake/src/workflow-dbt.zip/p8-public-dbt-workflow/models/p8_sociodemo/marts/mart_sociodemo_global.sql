-- Répartition des étudiants OpenClassrooms par année, région, genre et tranche d'âge

select
    year_path_started as year,
    region,
    case
        when gender_clean = 'F' then 'femme'
        when gender_clean = 'M' then 'homme'
        else 'Non renseigné'
    end as genre,
    age_group_insee as tranche_age,
    nb as nb_students,
    round(
        nb * 1.0 / nullif(sum(nb) over (partition by year_path_started), 0),
        4
    ) as part_students
from (
    select
        year_path_started,
        region,
        gender_clean,
        case
            when age_group in ('20-24 ans', '25-29 ans', '30-34 ans', '35-39 ans')
                then '20-39'
            when age_group in ('40-44 ans', '45-49 ans', '50-54 ans', '55-59 ans')
                then '40-59'
            when age_group = '60 ans ou plus'
                then '60+'
        end as age_group_insee,
        count(*) as nb
    from {{ ref('stg_students') }}
    where age_group in (
        '20-24 ans',
        '25-29 ans',
        '30-34 ans',
        '35-39 ans',
        '40-44 ans',
        '45-49 ans',
        '50-54 ans',
        '55-59 ans',
        '60 ans ou plus'
    )
    group by
        year_path_started,
        region,
        gender_clean,
        case
            when age_group in ('20-24 ans', '25-29 ans', '30-34 ans', '35-39 ans')
                then '20-39'
            when age_group in ('40-44 ans', '45-49 ans', '50-54 ans', '55-59 ans')
                then '40-59'
            when age_group = '60 ans ou plus'
                then '60+'
        end
) as oc_students