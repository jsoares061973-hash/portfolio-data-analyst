with oc_base as (

    select
        year_path_started as year,
        region,

        case
            when gender_clean = 'F' then 'femme'
            when gender_clean = 'M' then 'homme'
        end as genre,

        case
            when age_group_insee = '20-39 ans' then '20-39'
            when age_group_insee = '40-59 ans' then '40-59'
            when age_group_insee = '60 ans ou plus' then '60+'
        end as tranche_age,

        nb

    from {{ ref('mart_sociodemo_global') }}

    where gender_clean in ('F', 'M')
      and age_group_insee in ('20-39 ans', '40-59 ans', '60 ans ou plus')

),

years as (

    select distinct year
    from oc_base

),

oc as (

    select
        year,
        region,
        genre,
        tranche_age,
        sum(nb) as nb_students
    from oc_base
    group by
        year,
        region,
        genre,
        tranche_age

),

insee_base as (

    select
        case
            when region in ('Guadeloupe', 'Martinique', 'Guyane', 'La Réunion', 'Mayotte') then 'DROM'
            else region
        end as region,

        genre,

        case
            when tranche_age in ('60-74', '75+') then '60+'
            else tranche_age
        end as tranche_age,

        sum(population_insee_2025) as population_insee_2025

    from {{ ref('int_insee_population_region_genre_age') }}

    where tranche_age in ('20-39', '40-59', '60-74', '75+')

    group by
        case
            when region in ('Guadeloupe', 'Martinique', 'Guyane', 'La Réunion', 'Mayotte') then 'DROM'
            else region
        end,
        genre,
        case
            when tranche_age in ('60-74', '75+') then '60+'
            else tranche_age
        end

),

base_comparison as (

    select
        years.year,
        insee_base.region,
        insee_base.genre,
        insee_base.tranche_age,
        coalesce(oc.nb_students, 0) as nb_students,
        insee_base.population_insee_2025

    from years
    cross join insee_base

    left join oc
        on years.year = oc.year
       and insee_base.region = oc.region
       and insee_base.genre = oc.genre
       and insee_base.tranche_age = oc.tranche_age

),

final as (

    select
        year,
        region,
        genre,
        tranche_age,
        nb_students,

        nb_students / nullif(
            sum(nb_students) over (
                partition by year, genre, tranche_age
            ),
            0
        ) as part_students,

        population_insee_2025,

        population_insee_2025 / sum(population_insee_2025) over (
            partition by year, genre, tranche_age
        ) as part_insee

    from base_comparison

)

select
    *,
    part_students - part_insee as ecart_points
from final