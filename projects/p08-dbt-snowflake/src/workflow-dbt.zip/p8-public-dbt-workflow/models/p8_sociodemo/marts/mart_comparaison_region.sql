with oc as (
    select
        region,
        count(*) as nb_students
    from {{ ref('stg_students') }}
    group by region
),

insee as (
    select *
    from {{ ref('stg_insee_population_region') }}
)

select
    i.region,
    i.population_totale,
    coalesce(o.nb_students, 0) as nb_students,

    round(
        coalesce(o.nb_students, 0) * 1.0 / i.population_totale,
        6
    ) as part_oc

from insee i
left join oc o
    on i.region = o.region
order by part_oc desc