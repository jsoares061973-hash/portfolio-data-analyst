-- Export final pour Power BI : analyse interne OC et comparaison OC/INSEE

select
    year,
    region,
    genre,
    tranche_age,
    nb_students,
    null as population_insee_2025,
    nb_students / nullif(sum(nb_students) over (partition by year), 0) as part_students,
    null as part_insee,
    'Analyse interne OC' as perimetre_analyse
from (
    select
        year_path_started as year,
        region,
        case
            when gender_clean = 'F' then 'femme'
            when gender_clean = 'M' then 'homme'
            else 'Non renseigné'
        end as genre,
        case
            when age_group_insee = '20-39 ans' then '20-39'
            when age_group_insee = '40-59 ans' then '40-59'
            when age_group_insee = '60 ans ou plus' then '60+'
            else age_group_insee
        end as tranche_age,
        nb as nb_students
    from {{ ref('mart_sociodemo_global') }}
) as oc_base

union all

select
    year,
    region,
    genre,
    tranche_age,
    nb_students,
    population_insee_2025,
    nb_students / nullif(sum(nb_students) over (partition by year), 0) as part_students,
    population_insee_2025 / nullif(sum(population_insee_2025) over (partition by year), 0) as part_insee,
    'Comparaison OC vs INSEE' as perimetre_analyse
from (
    select
        2025 as year,
        i.region,
        i.genre,
        i.tranche_age,
        coalesce(o.nb_students, 0) as nb_students,
        i.population_insee_2025
    from (
        select
            region,
            genre,
            tranche_age,
            population_insee_2025
        from {{ ref('int_insee_population_region_genre_age') }}
        where genre in ('femme', 'homme')
          and tranche_age in ('20-39', '40-59', '60+')
    ) as i
    left join (
        select
            year,
            region,
            genre,
            tranche_age,
            sum(nb_students) as nb_students
        from (
            select
                year_path_started as year,
                region,
                case
                    when gender_clean = 'F' then 'femme'
                    when gender_clean = 'M' then 'homme'
                    else 'Non renseigné'
                end as genre,
                case
                    when age_group_insee = '20-39 ans' then '20-39'
                    when age_group_insee = '40-59 ans' then '40-59'
                    when age_group_insee = '60 ans ou plus' then '60+'
                    else age_group_insee
                end as tranche_age,
                nb as nb_students
            from {{ ref('mart_sociodemo_global') }}
        ) as oc_base
        where year = 2025
          and genre in ('femme', 'homme')
          and tranche_age in ('20-39', '40-59', '60+')
        group by
            year,
            region,
            genre,
            tranche_age
    ) as o
        on i.region = o.region
       and i.genre = o.genre
       and i.tranche_age = o.tranche_age
) as comparaison_base