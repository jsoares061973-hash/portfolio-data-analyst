select
    year_path_started,
    region,
    count(*) as nb,
    round(
        count(*) * 1.0
        / sum(count(*)) over (partition by year_path_started),
        4
    ) as proportion_year
from {{ ref('stg_students') }}
group by year_path_started, region