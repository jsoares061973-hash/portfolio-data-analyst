select
    year_path_started,
    age_group,
    gender_clean,
    count(*) as nb,
    round(
        count(*) * 1.0
        / sum(count(*)) over (partition by year_path_started, gender_clean),
        4
    ) as proportion_year
from {{ ref('stg_students') }}
group by year_path_started, age_group, gender_clean