select
    user_id,
    trim(path_category_name) as path_category_name,
    trim(age_group) as age_group,
    gender,
    case
        when gender is null or trim(gender) = '' then 'Non renseigné'
        else trim(gender)
    end as gender_clean,
    trim(region) as region,
    year_path_started
from {{ source('openclassrooms', 'students_data') }}