select
    case
        when r.libelle in ('Guadeloupe', 'Guyane', 'Martinique', 'La Réunion', 'Mayotte')
            then 'DROM'
        else r.libelle
    end as region,

    sum(to_number(replace(p.ensemble_20_39, ' ', ''))) as pop_20_39,

    sum(to_number(replace(p.ensemble_40_59, ' ', ''))) as pop_40_59,

    sum(
        to_number(replace(p.ensemble_60_74, ' ', ''))
        + to_number(replace(p.ensemble_75_plus, ' ', ''))
    ) as pop_60_plus,

    sum(to_number(replace(p.ensemble_total, ' ', ''))) as population_totale

from P8_OC_SOCIODEMO.RAW.INSEE_POP_DEPARTEMENTS_2025 p

join P8_OC_SOCIODEMO.RAW.COG_DEPARTEMENTS d
    on p.dep = d.dep

join P8_OC_SOCIODEMO.RAW.COG_REGIONS r
    on d.reg = r.reg

group by
    case
        when r.libelle in ('Guadeloupe', 'Guyane', 'Martinique', 'La Réunion', 'Mayotte')
            then 'DROM'
        else r.libelle
    end