with base as (

    select *
    from {{ source('openclassrooms', 'insee_pop_departements_2025') }}

),

final as (

    select dep, departement, 'homme' as genre, '20-39' as tranche_age, try_to_number(replace(hommes_20_39, ' ', '')) as population from base
    union all
    select dep, departement, 'homme' as genre, '40-59' as tranche_age, try_to_number(replace(hommes_40_59, ' ', '')) as population from base
    union all
    select dep, departement, 'homme' as genre, '60-74' as tranche_age, try_to_number(replace(hommes_60_74, ' ', '')) as population from base
    union all
    select dep, departement, 'homme', '75+', try_to_number(replace(hommes_75_plus, ' ', '')) from base

    union all

    select dep, departement, 'femme', '20-39', try_to_number(replace(femmes_20_39, ' ', '')) from base
    union all
    select dep, departement, 'femme', '40-59', try_to_number(replace(femmes_40_59, ' ', '')) from base
    union all
    select dep, departement, 'femme', '60-74', try_to_number(replace(femmes_60_74, ' ', '')) from base
    union all
    select dep, departement, 'femme', '75+', try_to_number(replace(femmes_75_plus, ' ', '')) from base

)

select *
from final